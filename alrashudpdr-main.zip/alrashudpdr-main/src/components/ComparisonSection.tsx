import React from 'react';
import { COMPARISON_DATA, WORKSHOP_INFO } from '../data/workshopData';
import { Check, X, ShieldAlert, ShieldCheck, Sparkles, MessageCircle, Phone } from 'lucide-react';

export const ComparisonSection: React.FC = () => {
  return (
    <section id="comparison" className="py-16 lg:py-24 bg-zinc-900/50 border-t border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <Sparkles className="w-3.5 h-3.5" />
            <span>مقارنة واقعية قبل اتخاذ قرارك</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            لماذا تختار التعديل على البارد بدلاً من السمكرة والرش؟
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            تعرّف على الفروقات الجوهرية وتأثيرها المباشر على فحص سيارتك وقيمتها المالية عند إعادة البيع
          </p>
        </div>

        {/* Comparison Table & Cards Container */}
        <div className="bg-zinc-950 rounded-2xl border border-zinc-800 overflow-hidden shadow-2xl">
          
          {/* Table Header */}
          <div className="grid grid-cols-1 md:grid-cols-12 bg-zinc-900/90 border-b border-zinc-800 text-center font-cairo">
            <div className="hidden md:block md:col-span-4 p-4 font-bold text-zinc-400 text-sm text-right pr-6">
              وجه المقارنة
            </div>
            
            {/* PDR Header Column */}
            <div className="md:col-span-4 p-4 bg-amber-500/10 border-r md:border-r-0 md:border-x border-amber-500/30 text-amber-300 font-black text-base sm:text-lg flex items-center justify-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <span>التعديل على البارد (ورشة الرشود)</span>
            </div>

            {/* Traditional Bodywork Header Column */}
            <div className="md:col-span-4 p-4 text-zinc-400 font-bold text-sm sm:text-base flex items-center justify-center gap-2">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <span>السمكرة والرش التقليدي</span>
            </div>
          </div>

          {/* Rows */}
          <div className="divide-y divide-zinc-800/70 font-tajawal text-sm">
            {COMPARISON_DATA.map((row, index) => (
              <div
                key={index}
                className="grid grid-cols-1 md:grid-cols-12 transition-colors hover:bg-zinc-900/30"
              >
                {/* Feature Name */}
                <div className="md:col-span-4 p-4 md:py-5 flex items-center font-bold text-zinc-200 bg-zinc-900/20 md:bg-transparent pr-4 md:pr-6 text-sm sm:text-base">
                  <span className="inline-block md:hidden text-xs text-amber-400 font-bold ml-2">العنصر:</span>
                  {row.feature}
                </div>

                {/* PDR Result */}
                <div className="md:col-span-4 p-4 md:py-5 bg-amber-500/[0.04] md:border-x border-amber-500/20 flex items-start gap-3 text-zinc-100">
                  <div className="w-6 h-6 rounded-full bg-emerald-950/80 border border-emerald-600 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="md:hidden font-bold text-xs text-amber-400 block mb-0.5">ورشة الرشود:</span>
                    <span className="text-xs sm:text-sm font-medium">{row.pdr.text}</span>
                  </div>
                </div>

                {/* Traditional Bodywork Result */}
                <div className="md:col-span-4 p-4 md:py-5 flex items-start gap-3 text-zinc-400 bg-zinc-950/40">
                  <div className="w-6 h-6 rounded-full bg-red-950/80 border border-red-800 text-red-400 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                    <X className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="md:hidden font-bold text-xs text-red-400 block mb-0.5">الورش التقليدية:</span>
                    <span className="text-xs sm:text-sm">{row.traditional.text}</span>
                  </div>
                </div>

              </div>
            ))}
          </div>

          {/* Bottom Summary Bar */}
          <div className="p-6 bg-gradient-to-b from-zinc-900 to-zinc-950 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-right">
              <span className="text-sm font-bold text-white font-cairo block">
                الخلاصة: لا ترش سيارتك وتفقد قيمتها!
              </span>
              <span className="text-xs text-zinc-400 font-tajawal">
                تواصل مع ورشة الرشود أولاً لتقييم إمكانية التعديل على البارد وحفظ قيمة سيارتك.
              </span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <a
                href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، أرغب في حجز موعد لتعديل صدمة على البارد والحفاظ على بوية الوكالة.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-bold font-cairo text-xs sm:text-sm transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>حجز بالواتساب</span>
              </a>
              <a
                href={`tel:${WORKSHOP_INFO.phone}`}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-zinc-700 px-5 py-2.5 rounded-xl font-bold font-cairo text-xs sm:text-sm transition-all"
              >
                <Phone className="w-4 h-4" />
                <span>اتصال ٠٥٧٥٥٦٧٧٦١</span>
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
