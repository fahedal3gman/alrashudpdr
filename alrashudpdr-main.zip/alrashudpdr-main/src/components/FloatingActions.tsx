import React, { useState, useEffect } from 'react';
import { Phone, MessageCircle, ArrowUp, Shield } from 'lucide-react';
import { WORKSHOP_INFO } from '../data/workshopData';

export const FloatingActions: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Floating Action Buttons for Desktop / Tablet (Bottom-left in RTL) */}
      <div className="fixed bottom-6 left-6 z-40 hidden sm:flex flex-col gap-3">
        {/* Scroll Top Button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-12 h-12 rounded-full bg-zinc-900/90 text-zinc-300 hover:text-white border border-zinc-700 hover:border-amber-500 shadow-xl flex items-center justify-center transition-all hover:scale-110"
            aria-label="العودة للأعلى"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}

        {/* Direct Call Floating Button */}
        <a
          id="floating-call-btn"
          href={`tel:${WORKSHOP_INFO.phone}`}
          className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-zinc-900 hover:bg-zinc-800 text-amber-400 border-2 border-amber-500 shadow-2xl transition-all hover:scale-110"
          aria-label="اتصال فوري بالورشة"
        >
          <Phone className="w-6 h-6 animate-bounce" />
          <span className="absolute left-full ml-3 px-3 py-1.5 bg-zinc-900 text-amber-400 font-bold text-xs rounded-xl border border-zinc-700 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none font-cairo shadow-lg flex items-center gap-1.5">
            <span>اتصال</span>
            <span dir="ltr" className="font-sans font-bold">057 556 7761</span>
          </span>
        </a>

        {/* WhatsApp Floating Pulse Button */}
        <a
          id="floating-whatsapp-btn"
          href={WORKSHOP_INFO.whatsappUrl()}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xl shadow-emerald-950/80 transition-all hover:scale-110"
          aria-label="محادثة واتساب فورية"
        >
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-400"></span>
          </span>
          <MessageCircle className="w-7 h-7" />
          <span className="absolute left-full ml-3 px-3 py-1.5 bg-emerald-700 text-white font-bold text-xs rounded-xl border border-emerald-500 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none font-cairo shadow-lg flex items-center gap-1.5">
            <span>واتساب</span>
            <span dir="ltr" className="font-sans font-bold">0575567761</span>
          </span>
        </a>
      </div>

      {/* Sticky Bottom Bar for Mobile Devices */}
      <div className="fixed bottom-0 left-0 right-0 z-50 sm:hidden bg-zinc-950/95 backdrop-blur-md border-t border-zinc-800 px-3 py-2.5 shadow-2xl">
        <div className="grid grid-cols-2 gap-2 font-cairo">
          
          {/* Mobile Call Button */}
          <a
            href={`tel:${WORKSHOP_INFO.phone}`}
            className="flex items-center justify-center gap-2 bg-zinc-900 border border-amber-500/50 text-amber-400 py-3 px-2 rounded-xl font-bold text-xs"
          >
            <Phone className="w-4 h-4 shrink-0" />
            <span className="flex items-center gap-1.5">
              <span>اتصال</span>
              <span dir="ltr" className="font-sans font-bold tracking-wide">057 556 7761</span>
            </span>
          </a>

          {/* Mobile WhatsApp Button */}
          <a
            href={WORKSHOP_INFO.whatsappUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-emerald-600 text-white py-3 px-2 rounded-xl font-bold text-xs shadow-lg shadow-emerald-950/50"
          >
            <MessageCircle className="w-4 h-4 shrink-0" />
            <span>حجز واتساب</span>
          </a>

        </div>
      </div>
    </>
  );
};
