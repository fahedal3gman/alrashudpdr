import React from 'react';
import { WORKSHOP_INFO } from '../data/workshopData';
import { MapPin, Clock, Phone, MessageCircle, Navigation, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const LocationAndHours: React.FC = () => {
  return (
    <section id="location" className="py-16 lg:py-24 bg-zinc-950 border-t border-zinc-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <MapPin className="w-3.5 h-3.5" />
            <span>الموقع والتواصل</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            موقع ورشة الرشود وأوقات العمل
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            نسعد باستقبالكم لمعاينة سياراتكم وتقديم أفضل خدمات التعديل على البارد
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Info cards column */}
          <div className="lg:col-span-6 space-y-4 flex flex-col justify-between">
            
            {/* Working Hours Card */}
            <div className="bg-zinc-900/80 border border-zinc-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold font-cairo text-white">
                    أوقات العمل واستقبال السيارات
                  </h3>
                  <span className="text-xs text-zinc-400 font-tajawal">
                    نعمل طوال أيام الأسبوع
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-zinc-800/80">
                {WORKSHOP_INFO.workingHours.map((sched, idx) => (
                  <div key={idx} className="flex items-center justify-between py-2 px-3 bg-zinc-950/60 rounded-xl text-xs sm:text-sm font-tajawal">
                    <span className="font-bold text-zinc-200">{sched.days}</span>
                    <span className="font-semibold text-amber-400">{sched.hours}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Contact Card */}
            <div className="bg-zinc-900/80 border border-zinc-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold font-cairo text-white">
                    أرقام التواصل والحجز الفوري
                  </h3>
                  <span className="text-xs text-zinc-400 font-tajawal">
                    رد سريع على المكالمات ورسائل الواتساب
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <a
                  href={`tel:${WORKSHOP_INFO.phone}`}
                  className="flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-zinc-700 p-3 rounded-xl font-bold font-cairo text-sm transition-all"
                >
                  <Phone className="w-4 h-4 shrink-0" />
                  <span dir="ltr" className="font-sans font-bold tracking-wide">057 556 7761</span>
                </a>

                <a
                  href={WORKSHOP_INFO.whatsappUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white p-3 rounded-xl font-bold font-cairo text-sm transition-all shadow-md shadow-emerald-950/50"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>محادثة واتساب</span>
                </a>
              </div>
            </div>

            {/* Free Inspection Badge */}
            <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/10 border border-amber-500/30 p-4 rounded-2xl flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-amber-400 shrink-0" />
              <div className="text-xs sm:text-sm font-tajawal">
                <strong className="text-white block font-bold">معاينة وتقييم مجاني بالكامل:</strong>
                <span className="text-zinc-300">شرفنا في موقع الورشة أو أرسل الصور عبر الواتساب وسنقدم لك التقييم بدون أي التزام.</span>
              </div>
            </div>

          </div>

          {/* Interactive Map Presentation Card */}
          <div className="lg:col-span-6 bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between">
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-amber-400" />
                  <h3 className="text-lg font-bold font-cairo text-white">
                    {WORKSHOP_INFO.fullName}
                  </h3>
                </div>
                <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-tajawal font-bold">
                  موقع الورشة
                </span>
              </div>

              <p className="text-xs sm:text-sm text-zinc-300 font-tajawal">
                {WORKSHOP_INFO.location.addressLine} - {WORKSHOP_INFO.location.district}
              </p>

              {/* Stylized Visual Map Placeholder / Interactive Direct link */}
              <div className="relative h-64 w-full rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800 group shadow-inner">
                {/* Background map pattern simulation */}
                <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#3f3f46_1px,transparent_1px)] [background-size:16px_16px]" />
                
                {/* Center pin pulse */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
                  <div className="relative mb-2">
                    <div className="w-12 h-12 rounded-full bg-amber-500/20 animate-ping absolute inset-0" />
                    <div className="w-12 h-12 rounded-full bg-amber-500 text-zinc-950 flex items-center justify-center shadow-2xl relative z-10 font-bold">
                      <MapPin className="w-6 h-6" />
                    </div>
                  </div>
                  
                  <h4 className="font-bold font-cairo text-white text-base">
                    {WORKSHOP_INFO.name} لتعديل الصدمات على البارد
                  </h4>
                  <p className="text-xs text-zinc-400 font-tajawal mt-1">
                    اضغط أدناه لفتح موقع الورشة مباشرة على خرائط Google وبدء التوجيه
                  </p>
                </div>

                <div className="absolute bottom-3 right-3 left-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <a
                    id="open-google-maps-btn"
                    href={WORKSHOP_INFO.location.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 py-2.5 px-3 rounded-xl text-xs font-bold font-cairo transition-all shadow-lg hover:scale-[1.02]"
                  >
                    <Navigation className="w-4 h-4" />
                    <span>فتح في خرائط Google</span>
                  </a>

                  <a
                    href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، أرغب في الحصول على لوكيشن ورشة الرشود وتأكيد موعد المعاينة.")}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-zinc-900/95 hover:bg-zinc-850 text-emerald-400 border border-emerald-500/40 py-2.5 px-3 rounded-xl text-xs font-bold font-cairo backdrop-blur-md transition-all shadow-lg"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>طلب اللوكيشن بالواتساب</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Quick directions bar */}
            <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400 font-tajawal">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                مواقف واسعة ومجهزة لاستقبال سيارتك
              </span>
              <a
                href={`tel:${WORKSHOP_INFO.phone}`}
                className="text-amber-400 hover:underline font-bold"
              >
                اتصال للاستدلال
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
