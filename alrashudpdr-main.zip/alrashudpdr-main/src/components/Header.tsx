import React, { useState } from 'react';
import { Phone, MessageCircle, ShieldCheck, Menu, X, Clock, MapPin, ChevronDown } from 'lucide-react';
import { WORKSHOP_INFO } from '../data/workshopData';

interface HeaderProps {
  onBookClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onBookClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'الرئيسية', href: '#hero' },
    { name: 'خدماتنا', href: '#services' },
    { name: 'الخدمة المتنقلة', href: '#booking' },
    { name: 'مقارنة التعديل والسمكرة', href: '#comparison' },
    { name: 'قبل وبعد', href: '#showcase' },
    { name: 'خطوات العمل', href: '#process' },
    { name: 'الأسئلة الشائعة', href: '#faq' },
    { name: 'الموقع وساعات العمل', href: '#location' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/80">
      {/* Top micro announcement bar */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-zinc-950 text-xs sm:text-sm font-bold py-1.5 px-4 text-center">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="hidden sm:flex items-center gap-4 text-xs font-semibold">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              السبت - الخميس: ٨ ص - ١٠ م
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              معاينة وفحص الصدمات مجاناً
            </span>
          </div>
          <div className="w-full sm:w-auto text-center font-tajawal flex items-center justify-center gap-2">
            <span>🛡️ الحفاظ على بوية الوكالة ١٠٠٪ بدون سمكرة وبدون رش دهان</span>
          </div>
          <a
            href={`tel:${WORKSHOP_INFO.phone}`}
            className="hidden sm:inline-flex items-center gap-1 bg-black text-amber-400 px-2.5 py-0.5 rounded-full text-xs font-bold hover:bg-zinc-900 transition-colors"
          >
            <Phone className="w-3 h-3" />
            <span>{WORKSHOP_INFO.formattedPhone}</span>
          </a>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <a href="#hero" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-zinc-950 font-black text-2xl shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-7 h-7 text-zinc-950" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black font-cairo text-white tracking-wide">
                  {WORKSHOP_INFO.name}
                </span>
                <span className="text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full">
                  PDR
                </span>
              </div>
              <span className="text-xs text-zinc-400 font-tajawal">
                تعديل وشفط صدمات على البارد
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 font-tajawal text-sm font-medium text-zinc-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-amber-400 transition-colors py-2"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Direct CTA Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              id="header-call-btn"
              href={`tel:${WORKSHOP_INFO.phone}`}
              className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-100 border border-zinc-700 px-4 py-2.5 rounded-xl font-bold text-sm transition-all hover:border-amber-500/50"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>اتصال {WORKSHOP_INFO.formattedPhone}</span>
            </a>

            <a
              id="header-whatsapp-btn"
              href={WORKSHOP_INFO.whatsappUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-emerald-900/30 hover:scale-105"
            >
              <MessageCircle className="w-4 h-4" />
              <span>واتساب سريع</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex lg:hidden items-center gap-2">
            <a
              href={`tel:${WORKSHOP_INFO.phone}`}
              className="p-2.5 bg-zinc-900 text-amber-400 rounded-xl border border-zinc-800"
              aria-label="Call workshop"
            >
              <Phone className="w-5 h-5" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-zinc-900 text-zinc-300 hover:text-white border border-zinc-800"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-zinc-900 border-b border-zinc-800 px-4 pt-3 pb-6 space-y-3 font-tajawal animate-in fade-in">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-4 py-3 rounded-lg text-zinc-200 hover:bg-zinc-800 hover:text-amber-400 font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-zinc-800 flex flex-col gap-2">
            <a
              href={`tel:${WORKSHOP_INFO.phone}`}
              className="w-full flex items-center justify-center gap-2 bg-zinc-800 text-amber-400 border border-zinc-700 py-3 rounded-xl font-bold"
            >
              <Phone className="w-5 h-5 shrink-0" />
              <span className="flex items-center gap-1.5">
                <span>اتصال مباشر:</span>
                <span dir="ltr" className="font-sans font-bold">057 556 7761</span>
              </span>
            </a>
            <a
              href={WORKSHOP_INFO.whatsappUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white py-3 rounded-xl font-bold"
            >
              <MessageCircle className="w-5 h-5 shrink-0" />
              <span>حجز واستفسار واتساب</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
