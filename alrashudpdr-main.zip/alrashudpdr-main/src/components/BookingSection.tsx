import React from 'react';
import { WORKSHOP_INFO } from '../data/workshopData';
import { 
  Phone, 
  MessageCircle, 
  Truck, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  Wrench, 
  Zap, 
  Camera,
  Navigation,
  Check
} from 'lucide-react';

export const BookingSection: React.FC = () => {
  const mobileServiceFeatures = [
    {
      icon: <MapPin className="w-5 h-5 text-amber-400" />,
      title: "نصلك أينما كنت",
      desc: "خدمة متنقلة تصلك عند باب بيتك، مقر عملك، أو معارض السيارات دون الحاجة لمغادرة مكانك."
    },
    {
      icon: <Wrench className="w-5 h-5 text-amber-400" />,
      title: "سيارة خدمة مجهزة بالكامل",
      desc: "مزودة بكافة أجهزة الشفط الهيدروليكية والحرارية ولوحات الإضاءة المتنقلة وأحدث أدوات الـ PDR."
    },
    {
      icon: <Clock className="w-5 h-5 text-amber-400" />,
      title: "توفير فائق للوقت والجهد",
      desc: "إصلاح فوري وسريع في موقعك خلال ساعات، لتستمر في يومك دون تعطيل أو الحاجة لسيارة بديلة."
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-amber-400" />,
      title: "نفس جودة ودقة الورشة",
      desc: "حفاظ كامل على صبغة الوكالة الأصلية ١٠٠٪ بدون سمكرة وبدون رش دهان وبأيدي فنيين محترفين."
    }
  ];

  const steps = [
    {
      num: "١",
      title: "أرسل صور الصدمة والموقع",
      desc: "صوّر الصدمة بالجوال وأرسلها مع موقعك (Location) عبر الواتساب على 0575567761 أو اتصل بنا مباشرة."
    },
    {
      num: "٢",
      title: "المعاينة وتأكيد وقت الوصول",
      desc: "يقوم الفني بفحص الصور مجاناً، وتأكيد إمكانية التعديل المتنقل، وتحديد موعد وصول سيارة الخدمة لموقعك."
    },
    {
      num: "٣",
      title: "الإصلاح المباشر في موقعك",
      desc: "تصل الورشة المتنقلة ويتم تعديل وشفط الصدمة أمام عينيك لتستلم سيارتك بحالتها الأصلية تماماً."
    }
  ];

  return (
    <section id="booking" className="py-16 lg:py-24 bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 border-t border-zinc-800 relative">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-4 py-1.5 rounded-full text-amber-400 text-xs sm:text-sm font-bold font-tajawal shadow-inner">
            <Truck className="w-4 h-4 text-amber-400" />
            <span>خدمة التعديل البارد المتنقل — نصلك إلى موقعك</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white leading-tight">
            نصلك عند باب بيتك أو عملك ونصلح صدمتك في موقعك
          </h2>

          <p className="text-sm sm:text-base text-zinc-300 font-tajawal leading-relaxed">
            لا داعي للخروج في الزحام أو ترك سيارتك لأيام! نوفر لك <strong className="text-amber-400">سيارة خدمة متنقلة مجهزة بالكامل</strong> بأحدث أدوات الـ PDR لإصلاح وشفط الصدمات أمام عينيك مع الحفاظ التام على بوية الوكالة.
          </p>
        </div>

        {/* Main Grid: Features & How It Works */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-12">
          
          {/* Left Column: Mobile Service Advantages */}
          <div className="lg:col-span-6 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden">
            <div className="space-y-6">
              
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
                    <Truck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold font-cairo text-white">
                      مميزات الورشة المتنقلة من الرشود
                    </h3>
                    <p className="text-xs text-zinc-400 font-tajawal">
                      أعلى معايير الراحة والدقة دون مغادرة موقعك
                    </p>
                  </div>
                </div>
                <span className="hidden sm:inline-flex text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-full font-bold">
                  متوفر الآن
                </span>
              </div>

              {/* Feature Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {mobileServiceFeatures.map((feat, idx) => (
                  <div 
                    key={idx}
                    className="bg-zinc-950/70 border border-zinc-800/80 p-4 rounded-2xl space-y-2 hover:border-amber-500/30 transition-colors"
                  >
                    <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                      {feat.icon}
                    </div>
                    <h4 className="text-sm font-bold font-cairo text-white">
                      {feat.title}
                    </h4>
                    <p className="text-xs text-zinc-400 font-tajawal leading-relaxed">
                      {feat.desc}
                    </p>
                  </div>
                ))}
              </div>

            </div>

            {/* Bottom highlight pill */}
            <div className="mt-6 pt-4 border-t border-zinc-800/80 flex items-center gap-3 bg-zinc-950/40 p-3 rounded-xl">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="text-xs text-zinc-300 font-tajawal">
                تعديل احترافي بنفس دقة وضمان الشغل داخل الورشة وبدون أي رش دهان نهائياً.
              </span>
            </div>

          </div>

          {/* Right Column: 3 Steps to Book Mobile Service */}
          <div className="lg:col-span-6 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
            
            <div className="space-y-6">
              <div className="pb-4 border-b border-zinc-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                    <Navigation className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold font-cairo text-white">
                      كيف تطلب خدمة التعديل المتنقل؟
                    </h3>
                    <p className="text-xs text-zinc-400 font-tajawal">
                      ٣ خطوات بسيطة ومباشرة عبر الواتساب أو الاتصال
                    </p>
                  </div>
                </div>
              </div>

              {/* Steps List */}
              <div className="space-y-4">
                {steps.map((st, i) => (
                  <div 
                    key={i}
                    className="flex items-start gap-4 bg-zinc-950/70 border border-zinc-800/80 p-4 rounded-2xl group hover:border-emerald-500/30 transition-colors"
                  >
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-zinc-950 font-black font-cairo text-base flex items-center justify-center shrink-0 shadow-md">
                      {st.num}
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold font-cairo text-white group-hover:text-amber-400 transition-colors">
                        {st.title}
                      </h4>
                      <p className="text-xs text-zinc-400 font-tajawal leading-relaxed">
                        {st.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Instant Booking CTA Container */}
            <div className="mt-6 pt-6 border-t border-zinc-800 space-y-3">
              <span className="text-xs text-zinc-400 font-tajawal block text-center">
                جاهز لطلب الخدمة المتنقلة أو الاستفسار؟ تواصل مباشرة:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* WhatsApp Button */}
                <a
                  id="mobile-service-whatsapp-btn"
                  href={WORKSHOP_INFO.whatsappUrl("السلام عليكم ورحمة الله، أرغب في طلب خدمة التعديل البارد المتنقل في موقعي. إليكم صور الصدمة وموقعي للمعاينة.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold font-cairo py-3.5 px-4 rounded-xl text-sm shadow-xl shadow-emerald-950/60 transition-all hover:scale-[1.02]"
                >
                  <MessageCircle className="w-5 h-5 shrink-0" />
                  <span className="flex items-center gap-1.5">
                    <span>طلب واتساب</span>
                    <span dir="ltr" className="font-sans font-bold">0575567761</span>
                  </span>
                </a>

                {/* Direct Call Button */}
                <a
                  id="mobile-service-call-btn"
                  href={`tel:${WORKSHOP_INFO.phone}`}
                  className="flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-800 text-amber-400 border border-amber-500/50 hover:border-amber-400 font-bold font-cairo py-3.5 px-4 rounded-xl text-sm transition-all"
                >
                  <Phone className="w-4 h-4 shrink-0" />
                  <span className="flex items-center gap-1.5">
                    <span>اتصال فوري</span>
                    <span dir="ltr" className="font-sans font-bold">057 556 7761</span>
                  </span>
                </a>
              </div>

              <div className="pt-3 border-t border-zinc-800/60 flex items-center justify-center gap-2 text-[11px] text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>فحص ومعاينة أولية مجانية 100% بدون أي التزام مالي مسبق.</span>
              </div>
            </div>

          </div>

        </div>

        {/* Bottom Banner: Workshop Location or Mobile Service Flexibility */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-right">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base sm:text-lg font-bold font-cairo text-white">
                ترغب بزيارة الورشة بنفسك بدلاً من الخدمة المتنقلة؟
              </h4>
              <p className="text-xs sm:text-sm text-zinc-400 font-tajawal">
                مرحباً بك دائماً في مقر الورشة للمعاينة المجانية والإصلاح الفوري. يسعدنا استقبالك طوال أيام الأسبوع.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href={WORKSHOP_INFO.location.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs sm:text-sm bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-5 py-3 rounded-xl font-bold font-tajawal transition-colors flex items-center gap-1.5"
            >
              <Navigation className="w-4 h-4 text-amber-400" />
              <span>موقعنا على خرائط Google</span>
            </a>
            <a
              href={WORKSHOP_INFO.whatsappUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs sm:text-sm bg-amber-500 hover:bg-amber-400 text-zinc-950 px-5 py-3 rounded-xl font-bold font-cairo transition-all shadow-lg shadow-amber-500/20"
            >
              حجز موعد بالورشة
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
