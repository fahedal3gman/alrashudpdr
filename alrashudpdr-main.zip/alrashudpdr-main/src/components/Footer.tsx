import React from 'react';
import { WORKSHOP_INFO } from '../data/workshopData';
import { ShieldCheck, Phone, MessageCircle, MapPin, Clock, ArrowUp, Lock, FileText, AlertCircle, Building2 } from 'lucide-react';
import { LegalModalType } from './LegalModals';

interface FooterProps {
  onOpenLegal: (type: LegalModalType) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-zinc-950 border-t border-zinc-800/80 pt-16 pb-24 lg:pb-12 text-zinc-400 font-tajawal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-zinc-800/60">
          
          {/* Col 1: Brand & Bio */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center text-zinc-950 font-black">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl font-black font-cairo text-white block">
                  {WORKSHOP_INFO.name}
                </span>
                <span className="text-xs text-amber-400">تعديل وشفط على البارد PDR</span>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-zinc-400">
              الورشة المتخصصة في استعادة صدمات وانبعاجات السيارات بدون سمكرة وبدون رش دهان، للحفاظ الكامل على بوية وقيمة سيارتك السوقية.
            </p>
            <div className="pt-1 text-[11px] text-zinc-500">
              <span>جميع الأعمال تخضع لضمان الحرفية وسلامة البوية الأصلية.</span>
            </div>
          </div>

          {/* Col 2: Services Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold font-cairo text-white">
              خدماتنا المتخصصة
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#booking" className="text-amber-400 font-bold hover:underline transition-colors flex items-center gap-1">
                  <span>خدمة التعديل البارد المتنقل (عند موقعك)</span>
                  <span className="text-[10px] bg-amber-500/20 px-1.5 py-0.5 rounded text-amber-300">جديد</span>
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">تعديل الصدمات على البارد PDR</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">شفط الصدمات بالأجهزة اللاصقة والحرارية</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">إصلاح آثار البرد والمطر</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">تعديل خطوط وحواف الهيكل الصعبة</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">تلميع وإزالة آثار الاحتكاك السطحي</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Direct Booking & Contact */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold font-cairo text-white">
              التواصل والحجز السريع
            </h4>
            <div className="space-y-2 text-xs">
              <a
                href={`tel:${WORKSHOP_INFO.phone}`}
                className="flex items-center gap-2 text-amber-400 hover:underline font-bold text-sm"
              >
                <Phone className="w-4 h-4 shrink-0" />
                <span dir="ltr" className="font-sans">057 556 7761</span>
              </a>
              <a
                href={WORKSHOP_INFO.whatsappUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-emerald-400 hover:underline font-bold text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>محادثة واتساب مباشرة</span>
              </a>
              <a
                href={WORKSHOP_INFO.location.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-zinc-300 hover:text-amber-400 hover:underline text-xs pt-1 transition-colors"
              >
                <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                <span>موقع الورشة على خرائط Google</span>
              </a>
              <div className="flex items-center gap-2 text-zinc-400 pt-1">
                <Clock className="w-4 h-4 text-zinc-500" />
                <span>السبت - الخميس: ٨ ص - ١٠ م</span>
              </div>
            </div>
          </div>

          {/* Col 4: Google Ads Policies & Trust */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold font-cairo text-white">
              السياسات والشفافية
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onOpenLegal('privacy')}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 text-zinc-400"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>سياسة الخصوصية وحماية البيانات</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenLegal('terms')}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 text-zinc-400"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>الشروط والأحكام واتفاقية الخدمة</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenLegal('disclaimer')}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 text-zinc-400"
                >
                  <AlertCircle className="w-3.5 h-3.5 text-blue-400" />
                  <span>إخلاء المسؤولية والإفصاح الإعلاني</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenLegal('business')}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 text-zinc-400"
                >
                  <Building2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>معلومات النشاط والترخيص</span>
                </button>
              </li>
            </ul>

            <div className="bg-zinc-900/60 p-3 rounded-xl border border-zinc-800 text-[11px] text-zinc-400 mt-2">
              <span className="text-amber-400 font-bold block mb-1">معاينة وفحص مجاني:</span>
              التقييم الأولي عبر الواتساب مجاني ولا يترتب عليه أي التزام مالي.
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div>
            © {new Date().getFullYear()} {WORKSHOP_INFO.fullName}. جميع الحقوق محفوظة.
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-zinc-300 transition-colors"
            >
              سياسة الخصوصية
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenLegal('terms')}
              className="hover:text-zinc-300 transition-colors"
            >
              الشروط والأحكام
            </button>
            <span>•</span>
            <button
              onClick={() => onOpenLegal('disclaimer')}
              className="hover:text-zinc-300 transition-colors"
            >
              إخلاء المسؤولية
            </button>
            <span>•</span>
            <button
              onClick={scrollToTop}
              className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-lg border border-zinc-800 transition-colors mr-2"
              title="العودة للأعلى"
              aria-label="العودة للأعلى"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};

