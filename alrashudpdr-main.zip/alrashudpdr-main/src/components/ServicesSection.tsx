import React from 'react';
import { SERVICES, WORKSHOP_INFO } from '../data/workshopData';
import { 
  ShieldCheck, 
  Maximize2, 
  CloudHail, 
  Activity, 
  Sparkles, 
  CheckCircle2, 
  Check, 
  MessageCircle, 
  Phone, 
  Truck,
  ArrowUpRight
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Truck: <Truck className="w-6 h-6 text-amber-400" />,
  ShieldCheck: <ShieldCheck className="w-6 h-6 text-amber-400" />,
  Maximize2: <Maximize2 className="w-6 h-6 text-amber-400" />,
  CloudHail: <CloudHail className="w-6 h-6 text-amber-400" />,
  Activity: <Activity className="w-6 h-6 text-amber-400" />,
  Sparkles: <Sparkles className="w-6 h-6 text-amber-400" />,
  CheckCircle2: <CheckCircle2 className="w-6 h-6 text-amber-400" />,
};

export const ServicesSection: React.FC = () => {
  return (
    <section id="services" className="py-16 lg:py-24 bg-zinc-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <span>حلول احترافية متكاملة</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            خدمات ورشة الرشود المتخصصة في تعديل وشفط الصدمات
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            جميع خدماتنا تُنفذ بأيدي فنيين متمرسين باستخدام أحدث أدوات الـ PDR العالمية مع ضمان الحفاظ الكامل على بوية الوكالة وبدون أي رش دهان.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800 hover:border-amber-500/40 rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 group hover:-translate-y-1 shadow-lg shadow-black/40"
            >
              <div className="space-y-4">
                
                {/* Header with Icon and Badge */}
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-zinc-950 transition-colors">
                    {iconMap[service.iconName] || <ShieldCheck className="w-6 h-6 text-amber-400" />}
                  </div>
                  {service.badge && (
                    <span className="text-[11px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2.5 py-1 rounded-full font-tajawal">
                      {service.badge}
                    </span>
                  )}
                </div>

                {/* Title and Short Description */}
                <div>
                  <h3 className="text-lg sm:text-xl font-bold font-cairo text-white group-hover:text-amber-400 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-zinc-400 font-tajawal mt-1 leading-relaxed">
                    {service.shortDesc}
                  </p>
                </div>

                {/* Features List */}
                <div className="space-y-2 pt-2 border-t border-zinc-800/60">
                  {service.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-zinc-300 font-tajawal">
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>

                {/* Recommended For */}
                <div className="bg-zinc-950/60 rounded-lg p-2.5 border border-zinc-800 text-[11px] text-zinc-400 font-tajawal">
                  <strong className="text-zinc-300 block mb-0.5">مناسب لـ:</strong>
                  {service.recommendedFor}
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-5 mt-4 border-t border-zinc-800 flex items-center gap-2">
                <a
                  href={WORKSHOP_INFO.whatsappUrl(`السلام عليكم، أود حجز واستفسار بخصوص خدمة (${service.title}) في ورشة الرشود.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 bg-emerald-600/90 hover:bg-emerald-500 text-white py-2.5 px-3 rounded-xl font-bold text-xs font-cairo transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>حجز عبر الواتساب</span>
                </a>
                <a
                  href={`tel:${WORKSHOP_INFO.phone}`}
                  className="p-2.5 bg-zinc-800 hover:bg-zinc-700 text-amber-400 rounded-xl border border-zinc-700 transition-colors"
                  title="اتصال سريع"
                  aria-label="اتصال سريع بالورشة"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Reassurance Banner */}
        <div className="mt-12 bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-900 p-6 sm:p-8 rounded-2xl border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-right">
            <h4 className="text-lg sm:text-xl font-bold font-cairo text-white flex items-center justify-center sm:justify-start gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <span>محتار إذا كانت صدمتك تقبل التعديل على البارد؟</span>
            </h4>
            <p className="text-xs sm:text-sm text-zinc-400 font-tajawal">
              فقط صوّر الصدمة من جوالك وأرسلها بالواتساب إلى الرقم <strong className="text-amber-400">{WORKSHOP_INFO.phone}</strong> وسيفيدك الفني مجاناً خلال دقائق.
            </p>
          </div>
          <a
            href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، عندي صدمة وأرغب في معرفة هل يمكن تعديلها على البارد بدون رش وكم تستغرق.")}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 px-6 py-3 rounded-xl font-bold font-cairo text-sm transition-all shadow-lg shadow-amber-500/20"
          >
            <MessageCircle className="w-4 h-4" />
            <span>أرسل صورة الصدمة الآن</span>
          </a>
        </div>

      </div>
    </section>
  );
};
