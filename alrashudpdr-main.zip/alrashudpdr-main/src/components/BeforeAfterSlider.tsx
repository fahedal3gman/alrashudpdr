import React from 'react';
import { WORKSHOP_INFO } from '../data/workshopData';
import { Shield, Check, MessageCircle, Sparkles, Clock, CheckCircle2 } from 'lucide-react';

export const BeforeAfterSlider: React.FC = () => {
  return (
    <section id="showcase" className="py-16 lg:py-24 bg-zinc-900/40 border-y border-zinc-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <Sparkles className="w-3.5 h-3.5" />
            <span>نتائج حقيقية لتقنية التعديل على البارد PDR</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            معرض نتائج أعمالنا (قبل وبعد التعديل)
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            شاهد دقة استعادة الصاج الأصلي وشفط الصدمات في ورشة الرشود بدون أي رش دهان أو سمكرة
          </p>
        </div>

        {/* Main Single Showcase Card */}
        <div className="bg-zinc-950 rounded-3xl border border-zinc-800 overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
            
            {/* Single Showcase Image Display */}
            <div className="lg:col-span-8 p-4 sm:p-6">
              <div className="relative rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900 shadow-inner group">
                <img
                  src="https://i.postimg.cc/D0dpSrFW/Chat-GPT-Image-Sep-6-2026-11-38-24-AM.png"
                  alt="نتائج تعديل وشفط الصدمات على البارد قبل وبعد ورشة الرشود"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto max-h-[550px] object-contain sm:object-cover group-hover:scale-[1.02] transition-transform duration-500"
                />
                
                {/* Floating pill badge */}
                <div className="absolute top-4 right-4 bg-zinc-950/85 backdrop-blur-md border border-amber-500/40 text-amber-300 px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-lg">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>تعديل صدمات احترافي ١٠٠٪</span>
                </div>
              </div>
            </div>

            {/* Showcase Details & Information Column */}
            <div className="lg:col-span-4 p-6 sm:p-8 lg:border-r border-zinc-800 bg-zinc-950/60 flex flex-col justify-between space-y-6">
              
              <div className="space-y-4">
                <div>
                  <span className="text-xs font-bold text-amber-400 font-tajawal block mb-1">
                    دقة الحرفية وأعلى المعايير
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold font-cairo text-white">
                    استعادة الصاج لحالته الأصلية
                  </h3>
                </div>

                <div className="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 space-y-2.5 text-xs sm:text-sm">
                  <div className="flex items-center justify-between text-zinc-300">
                    <span className="text-zinc-500">التقنية المستخدمة:</span>
                    <span className="font-semibold text-white">شفط وتعديل PDR على البارد</span>
                  </div>
                  <div className="flex items-center justify-between text-zinc-300">
                    <span className="text-zinc-500">بوية الوكالة:</span>
                    <span className="font-semibold text-emerald-400">حفاظ تام ١٠٠٪ بدون رش</span>
                  </div>
                  <div className="flex items-center justify-between text-zinc-300">
                    <span className="text-zinc-500">مدة الإنجاز:</span>
                    <span className="font-semibold text-amber-400 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      استلام سريع بنفس اليوم
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 font-tajawal leading-relaxed">
                  نضمن لك في ورشة الرشود معالجة الصدمات والانبعاجات بأحدث أجهزة الشفط ومساطر الإضاءة الدقيقة للحفاظ على القيمة السوقية لسيارتك.
                </p>

                {/* Highlights */}
                <div className="space-y-2.5 pt-1">
                  <span className="text-xs font-bold text-zinc-400 font-cairo block">
                    أهم المزايا والضمانات:
                  </span>
                  {[
                    "استعادة خطوط الهيكل والتصميم الدقيقة",
                    "عدم استخدام أي معجون سمكرة نهائياً",
                    "فحص وتثمين مجاني فوري للصدمة",
                    "حماية كاملة لسعر وقيمة السيارة عند البيع"
                  ].map((hl, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-zinc-200">
                      <div className="w-4 h-4 rounded-full bg-emerald-950 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-800/60">
                        <Check className="w-2.5 h-2.5" />
                      </div>
                      <span>{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Direct WhatsApp Consultation */}
              <div className="pt-4 border-t border-zinc-800/80">
                <a
                  href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، شاهدت نتائج أعمالكم وأرغب في استشارة ومعاينة صدمة بسيارتي لتعديلها على البارد.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl text-sm font-cairo transition-all shadow-lg shadow-emerald-950/40 hover:scale-[1.01]"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>استشرنا عن صدمتك عبر الواتساب</span>
                </a>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
