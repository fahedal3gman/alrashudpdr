import React from 'react';
import { X, ShieldCheck, FileText, AlertCircle, Building2 } from 'lucide-react';
import { WORKSHOP_INFO } from '../data/workshopData';

export type LegalModalType = 'privacy' | 'terms' | 'disclaimer' | 'business' | null;

interface LegalModalsProps {
  activeModal: LegalModalType;
  onClose: () => void;
}

export const LegalModals: React.FC<LegalModalsProps> = ({ activeModal, onClose }) => {
  if (!activeModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-zinc-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl max-h-[85vh] bg-zinc-900 border border-zinc-800 rounded-2xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden text-right font-tajawal"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-zinc-800 bg-zinc-950/60">
          <div className="flex items-center gap-3">
            {activeModal === 'privacy' && (
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
            )}
            {activeModal === 'terms' && (
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
            )}
            {activeModal === 'disclaimer' && (
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
                <AlertCircle className="w-5 h-5" />
              </div>
            )}
            {activeModal === 'business' && (
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
                <Building2 className="w-5 h-5" />
              </div>
            )}

            <div>
              <h3 className="text-lg sm:text-xl font-bold font-cairo text-white">
                {activeModal === 'privacy' && 'سياسة الخصوصية وحماية البيانات'}
                {activeModal === 'terms' && 'الشروط والأحكام واتفاقية الخدمة'}
                {activeModal === 'disclaimer' && 'إخلاء المسؤولية والشفافية الإعلانية'}
                {activeModal === 'business' && 'بيانات المنشأة والاعتماد الرسمي'}
              </h3>
              <span className="text-xs text-zinc-400">
                {WORKSHOP_INFO.fullName}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
            aria-label="إغلاق النافذة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-zinc-300 leading-relaxed">
          
          {/* Privacy Policy */}
          {activeModal === 'privacy' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">١. جمع المعلومات</h4>
                <p>
                  نحن في <strong>{WORKSHOP_INFO.fullName}</strong> نلتزم بحماية خصوصية زوار موقعنا وعملائنا. نقوم بجمع المعلومات التي تقدمها لنا طواعية (مثل رقم الجوال، اسم العميل، وصور صدمة السيارة) بغرض تقديم تقدير للتكلفة ومعاينة الخدمة والتواصل بخصوص الحجز.
                </p>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٢. استخدام البيانات</h4>
                <p>
                  تُستخدم البيانات المستلمة حصرياً لـ:
                </p>
                <ul className="list-disc list-inside space-y-1 mr-2 text-zinc-400">
                  <li>معاينة صور الصدمة وتحديد إمكانية التعديل على البارد بدون رش.</li>
                  <li>التواصل مع العميل عبر الواتساب أو الاتصال الهاتفي بخصوص الموعد والتسعير.</li>
                  <li>تنسيق موقع تقديم الخدمة المتنقلة في حال طلبها.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٣. سرية المعلومات وأمانها</h4>
                <p>
                  نلتزم بعدم بيع أو تأجير أو مشاركة أي بيانات شخصية أو أرقام هواتف لأي طرف ثالث، ويتم حفظ كافة المحادثات والصور في سرية وأمان تام وفق أعلى معايير الخصوصية.
                </p>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٤. ملفات تعريف الارتباط والإعلانات (Cookies)</h4>
                <p>
                  قد يستخدم الموقع ملفات تعريف ارتباط مجهولة المصدر لأغراض تحسين تجربة التصفح وقياس أداء الحملات الإعلانية عبر Google Ads. يمكنك تعطيل ملفات تعريف الارتباط من إعدادات المتصفح في أي وقت.
                </p>
              </div>
            </div>
          )}

          {/* Terms & Conditions */}
          {activeModal === 'terms' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">١. طبيعة الخدمة</h4>
                <p>
                  نقدم خدمات تعديل الصدمات على البارد (Paintless Dent Repair - PDR) باستخدام أحدث الأدوات التقنية دون استخدام معجون سمكرة ودون رش بوية، بهدف الحفاظ على صبغ الوكالة وقيمة السيارة.
                </p>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٢. التسعير والمعاينة الأولية</h4>
                <p>
                  التقييم الأولي عبر إرسال الصور في الواتساب هو تقدير مبدئي، ويتم اعتماد السعر النهائي بدقة بعد المعاينة المباشرة للصدمة تحت مساطر الإضاءة الدقيقة للتحقق من سلامة صبغ الوكالة الداخلي.
                </p>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٣. الخدمة المتنقلة</h4>
                <p>
                  في حال اختيار خدمة التعديل عند موقع العميل، يشترط توفر مساحة مناسبة وآمنة للعمل، ويتم تأكيد الموعد والموقع بالتنسيق المسبق عبر الواتساب أو الهاتف.
                </p>
              </div>

              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">٤. الضمان ورضا العميل</h4>
                <p>
                  نلتزم بتقديم أعلى مستويات الدقة الحرفية، ويتم تسليم السيارة للعميل بعد فحصه ورضاه التام عن النتيجة المستعادة.
                </p>
              </div>
            </div>
          )}

          {/* Disclaimer */}
          {activeModal === 'disclaimer' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">إفصاح الشفافية الإعلانية (Google Ads Compliance)</h4>
                <p>
                  هذا الموقع يمثل المنصة التعريفية الرسمية لـ <strong>{WORKSHOP_INFO.fullName}</strong>. نؤكد لعملائنا الكرام التزامنا بالشفافية الكاملة:
                </p>
                <ul className="list-disc list-inside space-y-1.5 mr-2 text-zinc-400 pt-2">
                  <li>جميع نتائج الصور والأعمال المعروضة تعكس تقنيات الإصلاح المتبعة في الورشة.</li>
                  <li>الفحص والمعاينة الأولية للصدمة مجانية تماماً ولا تلزم العميل بأي التزام مالي مسبق.</li>
                  <li>نحن مركز صيانة وورشة سيارات مستقلة متخصصة، ولا ندعي تمثيل أي وكالة سيارات تجارية كطرف أصيل.</li>
                  <li>أرقام التواصل الرسمية المعتمدة هي: <span dir="ltr" className="font-bold text-amber-400">057 556 7761</span>.</li>
                </ul>
              </div>
            </div>
          )}

          {/* Business Info */}
          {activeModal === 'business' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold font-cairo text-amber-400 text-base mb-1">بيانات النشاط التجاري</h4>
                <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">اسم المنشأة:</span>
                    <span className="font-bold text-white">{WORKSHOP_INFO.fullName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">النشاط:</span>
                    <span className="text-zinc-300">تعديل وشفط صدمات السيارات على البارد (PDR)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">الهاتف المعتمد:</span>
                    <span dir="ltr" className="font-bold text-amber-400">057 556 7761</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">اللوكيشن والخرائط:</span>
                    <a href={WORKSHOP_INFO.location.mapsUrl} target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline">
                      عرض في Google Maps
                    </a>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-zinc-800 bg-zinc-950/70 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold font-cairo rounded-xl text-xs sm:text-sm transition-all"
          >
            إغلاق ومتابعة التصفح
          </button>
        </div>

      </div>
    </div>
  );
};
