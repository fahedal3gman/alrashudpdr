import React from 'react';
import { TESTIMONIALS, WORKSHOP_INFO } from '../data/workshopData';
import { Star, ShieldCheck, Quote, ThumbsUp } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  return (
    <section className="py-16 lg:py-24 bg-zinc-950 relative border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <ThumbsUp className="w-3.5 h-3.5" />
            <span>ثقة وتجارب عملائنا الكرام</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            ماذا يقول عملاء ورشة الرشود؟
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            آراء وتجارب حقيقية لأصحاب السيارات الذين وثقوا بنا للحفاظ على بوية وسعر مركباتهم
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item, index) => (
            <div
              key={index}
              className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 flex flex-col justify-between relative hover:border-zinc-700 transition-all shadow-xl group"
            >
              <div className="space-y-4">
                
                {/* Rating stars */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-[11px] text-zinc-500 font-tajawal">
                    {item.date}
                  </span>
                </div>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-zinc-300 font-tajawal leading-relaxed">
                  "{item.comment}"
                </p>

              </div>

              {/* Author & Car Info */}
              <div className="pt-4 mt-4 border-t border-zinc-800 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold font-cairo text-white">
                    {item.name}
                  </h4>
                  <span className="text-xs text-amber-400 font-tajawal block">
                    {item.car}
                  </span>
                </div>
                <span className="text-[11px] bg-zinc-950 text-zinc-400 px-2.5 py-1 rounded-md border border-zinc-800 font-tajawal">
                  {item.service}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
