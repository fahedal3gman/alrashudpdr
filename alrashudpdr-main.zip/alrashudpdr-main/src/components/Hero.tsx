import React from 'react';
import { Phone, MessageCircle, CheckCircle2, Award, Zap, Camera, Truck, Sparkles } from 'lucide-react';
import { WORKSHOP_INFO } from '../data/workshopData';

interface HeroProps {
  onDirectBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onDirectBooking }) => {
  return (
    <section id="hero" className="relative pt-4 pb-12 lg:pt-6 lg:pb-16 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Full Clean Top Banner - Zero shading, 100% visible on all screens */}
        <div className="relative w-full rounded-2xl sm:rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl bg-zinc-900">
          <img
            src="https://i.postimg.cc/GtJg4Fr4/Chat-GPT-Image-Sep-6-2026-11-41-14-AM.png"
            alt="ورشة الرشود لتعديل صدمات السيارات على البارد PDR"
            referrerPolicy="no-referrer"
            className="w-full h-auto block select-none"
          />
        </div>

        {/* Quick Action CTAs & Highlights directly below banner */}
        <div className="bg-zinc-900/90 border border-zinc-800 p-5 sm:p-7 rounded-2xl sm:rounded-3xl shadow-xl space-y-6">
          
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            
            {/* Direct Booking Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
              {/* WhatsApp Button */}
              <a
                id="hero-whatsapp-cta"
                href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، أرغب في إرسال صور صدمة بالسيارة لمعاينتها وحجز موعد تعديل على البارد لدى ورشة الرشود.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-500 text-white px-6 sm:px-7 py-4 rounded-xl font-bold font-cairo text-base sm:text-lg shadow-xl shadow-emerald-950/60 hover:scale-[1.02] transition-all"
              >
                <MessageCircle className="w-6 h-6 shrink-0" />
                <span className="flex items-center gap-2">
                  <span>حجز بالواتساب</span>
                  <span dir="ltr" className="font-sans font-bold tracking-wider text-emerald-100">0575567761</span>
                </span>
              </a>

              {/* Direct Call Button */}
              <a
                id="hero-phone-cta"
                href={`tel:${WORKSHOP_INFO.phone}`}
                className="flex items-center justify-center gap-3 bg-zinc-950 hover:bg-zinc-800 text-amber-400 border-2 border-amber-500/60 hover:border-amber-400 px-6 sm:px-7 py-4 rounded-xl font-bold font-cairo text-base sm:text-lg transition-all"
              >
                <Phone className="w-6 h-6 shrink-0" />
                <span className="flex items-center gap-2">
                  <span>اتصال فوري</span>
                  <span dir="ltr" className="font-sans font-bold tracking-wide">057 556 7761</span>
                </span>
              </a>
            </div>

            {/* Mobile Service Announcement & WhatsApp Photo Helper */}
            <div className="flex flex-wrap items-center justify-center lg:justify-end gap-3 text-xs sm:text-sm font-tajawal text-zinc-300">
              <span className="flex items-center gap-1.5 bg-zinc-950/80 px-3.5 py-2 rounded-xl border border-zinc-800">
                <Camera className="w-4 h-4 text-amber-400 shrink-0" />
                <span>أرسل صورة الصدمة للمعاينة والتسعير الفوري</span>
              </span>
              <a 
                href="#booking" 
                className="flex items-center gap-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3.5 py-2 rounded-xl font-bold transition-colors"
              >
                <Truck className="w-4 h-4" />
                <span>خدمة التعديل المتنقل عند موقعك</span>
              </a>
            </div>

          </div>

          {/* Key Value Badges Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-zinc-800/80">
            <div className="flex items-center gap-2.5 bg-zinc-950/60 border border-zinc-800/80 p-3 rounded-xl">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-zinc-200">حفاظ تام على صبغ الوكالة</span>
            </div>
            <div className="flex items-center gap-2.5 bg-zinc-950/60 border border-zinc-800/80 p-3 rounded-xl">
              <Zap className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-zinc-200">استلام بنفس اليوم</span>
            </div>
            <div className="flex items-center gap-2.5 bg-zinc-950/60 border border-zinc-800/80 p-3 rounded-xl">
              <Award className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-zinc-200">معاينة وفحص مجاني</span>
            </div>
            <div className="flex items-center gap-2.5 bg-zinc-950/60 border border-zinc-800/80 p-3 rounded-xl">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="text-xs sm:text-sm font-semibold text-zinc-200">أحدث أجهزة الـ PDR</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

