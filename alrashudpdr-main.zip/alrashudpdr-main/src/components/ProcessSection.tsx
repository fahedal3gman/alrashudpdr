import React from 'react';
import { WORK_STEPS, WORKSHOP_INFO } from '../data/workshopData';
import { Camera, CalendarCheck, Scan, Wrench, Award, MessageCircle, Phone, ArrowLeft } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Camera: <Camera className="w-6 h-6 text-amber-400" />,
  CalendarCheck: <CalendarCheck className="w-6 h-6 text-amber-400" />,
  Scan: <Scan className="w-6 h-6 text-amber-400" />,
  Wrench: <Wrench className="w-6 h-6 text-amber-400" />,
  Award: <Award className="w-6 h-6 text-amber-400" />,
};

export const ProcessSection: React.FC = () => {
  return (
    <section id="process" className="py-16 lg:py-24 bg-zinc-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <span>سهولة وسرعة الإجراءات</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            كيف تتم عملية التعديل في ورشة الرشود؟
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base leading-relaxed">
            خطوات بسيطة وسريعة تبدأ برسالة واتساب وتنتهي باستلام سيارتك كأنها لم تُصدم من قبل
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 relative">
          {WORK_STEPS.map((step, index) => (
            <div
              key={index}
              className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 flex flex-col justify-between relative hover:border-amber-500/50 hover:bg-zinc-900 transition-all duration-300 group shadow-lg"
            >
              {/* Step Top Badge */}
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  {iconMap[step.iconName] || <Wrench className="w-5 h-5 text-amber-400" />}
                </div>
                <span className="text-2xl font-black font-cairo text-zinc-600 group-hover:text-amber-400 transition-colors">
                  {step.number}
                </span>
              </div>

              {/* Title & Description */}
              <div className="space-y-2">
                <h3 className="text-base font-bold font-cairo text-white group-hover:text-amber-300 transition-colors">
                  {step.title}
                </h3>
                <p className="text-xs text-zinc-400 font-tajawal leading-relaxed">
                  {step.desc}
                </p>
              </div>

              {/* Step indicator arrow for desktop */}
              {index < WORK_STEPS.length - 1 && (
                <div className="hidden lg:block absolute -left-3 top-1/2 -translate-y-1/2 z-10 text-zinc-600 pointer-events-none">
                  <ArrowLeft className="w-5 h-5 text-zinc-700" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Action Callout */}
        <div className="mt-12 text-center bg-zinc-900/80 border border-zinc-800 p-6 rounded-2xl max-w-2xl mx-auto space-y-4">
          <h4 className="text-base sm:text-lg font-bold font-cairo text-white">
            جاهز لبدء الخطوة الأولى الآن؟
          </h4>
          <p className="text-xs sm:text-sm text-zinc-400 font-tajawal">
            أرسل صورة الصدمة وسيرد عليك الفني فوراً بالتفاصيل والموعد المناسب
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <a
              href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، أرغب في إرسال صورة الصدمة للمعاينة والحجز المباشر في ورشة الرشود.")}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3 rounded-xl text-sm font-cairo shadow-lg shadow-emerald-950/50 transition-all hover:scale-105"
            >
              <MessageCircle className="w-4 h-4" />
              <span>إرسال الصورة بالواتساب: ٠٥٧٥٥٦٧٧٦١</span>
            </a>
            <a
              href={`tel:${WORKSHOP_INFO.phone}`}
              className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-zinc-700 font-bold px-6 py-3 rounded-xl text-sm font-cairo transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>اتصال مباشر</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
