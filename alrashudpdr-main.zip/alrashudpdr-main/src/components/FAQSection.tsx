import React, { useState } from 'react';
import { FAQ_LIST, WORKSHOP_INFO } from '../data/workshopData';
import { HelpCircle, ChevronDown, MessageCircle, Phone } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 lg:py-24 bg-zinc-900/30 border-t border-zinc-800 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 rounded-full text-amber-400 text-xs font-bold font-tajawal">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>إجابات واضحة وشفافة</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black font-cairo text-white">
            الأسئلة الشائعة حول التعديل على البارد
          </h2>
          <p className="text-zinc-400 font-tajawal text-sm sm:text-base">
            كل ما تود معرفته عن تقنية PDR والحفاظ على بوية الوكالة في ورشة الرشود
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {FAQ_LIST.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-zinc-900/80 border border-zinc-800 rounded-2xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggleAccordion(index)}
                  className="w-full p-5 text-right flex items-center justify-between gap-4 hover:text-amber-400 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="font-bold font-cairo text-sm sm:text-base text-zinc-100">
                    {faq.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-amber-500 text-zinc-950' : 'text-zinc-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-zinc-300 font-tajawal leading-relaxed border-t border-zinc-800/60 bg-zinc-950/40">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions prompt */}
        <div className="mt-10 bg-zinc-950 p-6 rounded-2xl border border-zinc-800 text-center space-y-3">
          <h4 className="text-sm sm:text-base font-bold font-cairo text-white">
            هل لديك سؤال آخر لم تجد إجابته هنا؟
          </h4>
          <p className="text-xs text-zinc-400 font-tajawal">
            تواصل معنا عبر الواتساب وسيسعد فني الورشة بالإجابة عليك فوراً
          </p>
          <div className="pt-1 flex items-center justify-center gap-3">
            <a
              href={WORKSHOP_INFO.whatsappUrl("السلام عليكم، لدي استفسار بخصوص التعديل على البارد في ورشة الرشود.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold font-cairo px-5 py-2.5 rounded-xl transition-all shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>استفسار واتساب: ٠٥٧٥٥٦٧٧٦١</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
