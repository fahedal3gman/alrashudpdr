import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { ComparisonSection } from './components/ComparisonSection';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { ProcessSection } from './components/ProcessSection';
import { BookingSection } from './components/BookingSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FAQSection } from './components/FAQSection';
import { LocationAndHours } from './components/LocationAndHours';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { LegalModals, LegalModalType } from './components/LegalModals';

export default function App() {
  const [activeLegalModal, setActiveLegalModal] = useState<LegalModalType>(null);

  const scrollToBooking = () => {
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-amber-500 selection:text-black antialiased overflow-x-hidden">
      {/* Top Header */}
      <Header onBookClick={scrollToBooking} />

      {/* Main Content Flow */}
      <main>
        {/* Hero Section with Value proposition & quick direct calls/whatsapp */}
        <Hero onDirectBooking={scrollToBooking} />

        {/* Specialized Services Grid */}
        <ServicesSection />

        {/* Comparison: PDR in Al-Rashood vs Traditional Bodywork */}
        <ComparisonSection />

        {/* Interactive Before & After Showcase Slider */}
        <BeforeAfterSlider />

        {/* Work Steps & Process */}
        <ProcessSection />

        {/* Fast Booking & WhatsApp Request Form */}
        <BookingSection />

        {/* Customer Testimonials & Trust */}
        <TestimonialsSection />

        {/* Frequently Asked Questions */}
        <FAQSection />

        {/* Location, Working Hours & Maps */}
        <LocationAndHours />
      </main>

      {/* Footer with Google Ads Compliant Policies */}
      <Footer onOpenLegal={(type) => setActiveLegalModal(type)} />

      {/* Floating Call & WhatsApp Buttons */}
      <FloatingActions />

      {/* Policy & Legal Modals for Google Ads destination compliance */}
      <LegalModals
        activeModal={activeLegalModal}
        onClose={() => setActiveLegalModal(null)}
      />
    </div>
  );
}

