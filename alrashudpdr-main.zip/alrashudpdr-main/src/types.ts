export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  iconName: string;
  badge?: string;
  recommendedFor: string;
}

export interface BeforeAfterCase {
  id: string;
  title: string;
  carModel: string;
  damageType: string;
  duration: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  highlights: string[];
}

export interface ComparisonPoint {
  feature: string;
  pdr: {
    text: string;
    positive: boolean;
  };
  traditional: {
    text: string;
    positive: boolean;
  };
}

export interface StepItem {
  number: string;
  title: string;
  desc: string;
  iconName: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface TestimonialItem {
  name: string;
  car: string;
  comment: string;
  rating: number;
  service: string;
  date: string;
}
